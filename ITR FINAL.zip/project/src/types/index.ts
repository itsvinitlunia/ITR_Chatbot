export interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  isQuickOptions?: boolean;
  quickOptions?: string[];
}

export interface QuickQuestion {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}