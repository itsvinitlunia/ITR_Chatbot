// TypeScript port of the Python chatbot logic
import { Message } from '../types';

// Global dictionary to store conversation states for different sessions
const conversations: { [sessionId: string]: ConversationState } = {};

interface ConversationState {
  step: string;
  userData: { [key: string]: any };
  context: { [key: string]: any };
}

interface ChatResponse {
  message: string;
  quickOptions?: string[];
}

export function getConversationState(sessionId: string): ConversationState {
  if (!conversations[sessionId]) {
    conversations[sessionId] = {
      step: 'start',
      userData: {},
      context: {}
    };
  }
  return conversations[sessionId];
}

export function updateConversationState(
  sessionId: string, 
  step: string, 
  userData: { [key: string]: any } = {}, 
  context: { [key: string]: any } = {}
) {
  const state = getConversationState(sessionId);
  state.step = step;
  Object.assign(state.userData, userData);
  Object.assign(state.context, context);
}

function extractKeywords(message: string): string[] {
  const normalizedMessage = message.toLowerCase().trim();
  return normalizedMessage.match(/\b\w+\b/g) || [];
}

function containsKeywords(message: string, keywords: string[]): boolean {
  const messageWords = extractKeywords(message);
  return keywords.some(keyword => 
    messageWords.some(word => word.includes(keyword.toLowerCase()))
  );
}

export function processChatMessage(message: string, sessionId: string = 'default'): ChatResponse {
  const state = getConversationState(sessionId);
  const currentStep = state.step;
  const userData = state.userData;
  
  // Handle global commands first
  if (containsKeywords(message, ['start over', 'restart', 'reset'])) {
    updateConversationState(sessionId, 'start', {}, {});
    return {
      message: "Let's start fresh! Are you ready to begin your ITR filing process?",
      quickOptions: ['Yes, start filing', 'Help me understand', 'Which ITR form should I use?']
    };
  }
  
  if (containsKeywords(message, ['help', 'support', 'assistance'])) {
    const helpText = `I can help you with ITR filing! Here's what I can assist you with:

📋 **ITR Form Selection**: Find the right ITR form based on your income sources
📄 **Document Checklist**: Get a list of required documents  
💰 **Tax Calculation**: Calculate your tax liability
🔗 **Aadhaar Linking**: Guide you through PAN-Aadhaar linking
📊 **Filing Process**: Step-by-step filing assistance

Just tell me what you need help with!`;
    
    return {
      message: helpText,
      quickOptions: ['Start filing process', 'Which ITR form?', 'Document checklist', 'Tax calculation']
    };
  }
  
  // Start of the flowchart - Entry point
  if (currentStep === 'start') {
    if (containsKeywords(message, ['start', 'begin', 'file', 'filing', 'yes', 'proceed'])) {
      updateConversationState(sessionId, 'check_aadhaar_link');
      return {
        message: "Great! Let's begin your ITR filing process. First, I need to verify - Is your Aadhaar linked with your PAN?",
        quickOptions: ['Yes, it\'s linked', 'No, not linked', 'Not sure, how to check?']
      };
    }
    
    if (containsKeywords(message, ['which', 'itr', 'form', 'type'])) {
      return {
        message: getITRFormGuide(),
        quickOptions: ['Start filing process', 'More information', 'Help me choose']
      };
    }
    
    return {
      message: "Welcome to ITR Filing Assistant! I'll help you file your Income Tax Return step by step. Ready to start?",
      quickOptions: ['Start filing process', 'Help', 'Which ITR form should I use?']
    };
  }
  
  // Check Aadhaar-PAN linking
  if (currentStep === 'check_aadhaar_link') {
    if (containsKeywords(message, ['yes', 'linked', 'done', 'completed'])) {
      updateConversationState(sessionId, 'select_filer_type');
      return {
        message: "Perfect! Your Aadhaar is linked with PAN. Now, let me identify what type of filer you are. Are you an Individual taxpayer?",
        quickOptions: ['Individual taxpayer', 'Company', 'Tax Professional', 'Other entity']
      };
    }
    
    if (containsKeywords(message, ['no', 'not linked', 'unlinked'])) {
      updateConversationState(sessionId, 'guide_aadhaar_linking');
      return {
        message: getAadhaarLinkingGuide(),
        quickOptions: ['Done linking', 'Need help', 'Continue anyway']
      };
    }
    
    if (containsKeywords(message, ['not sure', 'dont know', 'unsure', 'check'])) {
      return {
        message: `You can check if your Aadhaar is linked with PAN by:

🌐 **Online**: Visit the Income Tax e-filing portal
📱 **SMS**: Send SMS to 567678 or 56161  
📞 **Call**: Contact IT helpdesk at 1800-103-0025

Is your Aadhaar linked with PAN?`,
        quickOptions: ['Yes, it\'s linked', 'No, not linked', 'Will check later']
      };
    }
    
    return {
      message: "I need to know about your Aadhaar-PAN linking status to proceed. Is your Aadhaar linked with your PAN?",
      quickOptions: ['Yes', 'No', 'Not sure']
    };
  }
  
  // Guide for Aadhaar linking
  if (currentStep === 'guide_aadhaar_linking') {
    if (containsKeywords(message, ['done', 'linked', 'completed'])) {
      updateConversationState(sessionId, 'select_filer_type');
      return {
        message: "Excellent! Now that your Aadhaar is linked, let's proceed. What type of filer are you?",
        quickOptions: ['Individual', 'Company', 'Professional', 'Other entity']
      };
    }
    
    if (containsKeywords(message, ['continue', 'anyway', 'proceed'])) {
      updateConversationState(sessionId, 'select_filer_type');
      return {
        message: "I recommend linking Aadhaar with PAN for smooth processing, but let's continue. What type of filer are you?",
        quickOptions: ['Individual', 'Company', 'Professional', 'Other entity']
      };
    }
    
    return {
      message: getAadhaarLinkingGuide(),
      quickOptions: ['Done linking', 'Continue anyway', 'Need help']
    };
  }
  
  // Select filer type
  if (currentStep === 'select_filer_type') {
    if (containsKeywords(message, ['individual', 'person', 'salaried', 'employee'])) {
      updateConversationState(sessionId, 'individual_type_selection', { filerType: 'individual' });
      return {
        message: "Great! You're an individual taxpayer. Now let me understand your income sources better. What's your primary income source?",
        quickOptions: ['Salary/Employment', 'Business', 'Professional/Freelance', 'Multiple sources']
      };
    }
    
    if (containsKeywords(message, ['company', 'corporate', 'corporation'])) {
      updateConversationState(sessionId, 'company_filing', { filerType: 'company' });
      return {
        message: "You're filing for a Company. You'll need to use ITR-6 form. Do you have all required company documents ready?",
        quickOptions: ['Yes, have documents', 'No, need help', 'What documents needed?']
      };
    }
    
    if (containsKeywords(message, ['professional', 'ca', 'tax professional', 'agent'])) {
      updateConversationState(sessionId, 'professional_filing', { filerType: 'professional' });
      return {
        message: "You're a Tax Professional. You can proceed with professional tools and ITR-6 form. Do you need access to professional features?",
        quickOptions: ['Yes, professional features', 'Client filing', 'Bulk filing']
      };
    }
    
    return {
      message: "I need to identify your filer type to guide you to the right ITR form. Are you an Individual, Company, Tax Professional, or Other Entity?",
      quickOptions: ['Individual', 'Company', 'Tax Professional', 'Other entity']
    };
  }
  
  // Individual type selection
  if (currentStep === 'individual_type_selection') {
    if (containsKeywords(message, ['salary', 'salaried', 'employee', 'employment'])) {
      updateConversationState(sessionId, 'check_income_limit', { incomeType: 'salary' });
      return {
        message: "You have salary income. What's your annual income range? This helps determine the right ITR form.",
        quickOptions: ['Below ₹50 lakhs', 'Above ₹50 lakhs', 'Not sure']
      };
    }
    
    if (containsKeywords(message, ['business', 'trade', 'commerce'])) {
      updateConversationState(sessionId, 'business_income_check', { incomeType: 'business' });
      return {
        message: "You have business income. Is your business turnover below ₹2 crores and you want to use presumptive taxation?",
        quickOptions: ['Yes, presumptive taxation', 'No, regular taxation', 'What is presumptive taxation?']
      };
    }
    
    if (containsKeywords(message, ['profession', 'professional', 'freelance', 'consultant'])) {
      updateConversationState(sessionId, 'profession_income_check', { incomeType: 'profession' });
      return {
        message: "You have professional income. Is your professional receipt below ₹50 lakhs and you want to use presumptive taxation?",
        quickOptions: ['Yes, presumptive taxation', 'No, regular taxation', 'What is presumptive taxation?']
      };
    }
    
    if (containsKeywords(message, ['multiple', 'various', 'different', 'mixed'])) {
      updateConversationState(sessionId, 'multiple_income_check');
      return {
        message: getMultipleIncomeGuide(),
        quickOptions: ['Salary + Capital gains', 'Salary + House property', 'Business + Other', 'Need help']
      };
    }
    
    return {
      message: "What's your primary source of income? This helps me recommend the right ITR form.",
      quickOptions: ['Salary', 'Business', 'Professional', 'Multiple sources']
    };
  }
  
  // Check income limit for salaried individuals
  if (currentStep === 'check_income_limit') {
    if (containsKeywords(message, ['below', 'under', '50', 'less'])) {
      updateConversationState(sessionId, 'check_other_income', { incomeRange: 'below_50L' });
      return {
        message: "Your income is below ₹50 lakhs. Do you have any other income sources like house property, capital gains, or other sources?",
        quickOptions: ['Only salary', 'House property', 'Capital gains', 'Other sources']
      };
    }
    
    if (containsKeywords(message, ['above', 'over', '50', 'more', 'higher'])) {
      updateConversationState(sessionId, 'itr2_recommendation', { incomeRange: 'above_50L' });
      return {
        message: "Since your income is above ₹50 lakhs, you need to file ITR-2. Shall we proceed with ITR-2 filing process?",
        quickOptions: ['Yes, proceed with ITR-2', 'Tell me more about ITR-2', 'What documents needed?']
      };
    }
    
    if (containsKeywords(message, ['not sure', 'unsure', 'dont know'])) {
      return {
        message: `To determine your income range, consider:

💰 **Gross Salary**: Before deductions
🏠 **House Property**: Rental income (if any)  
📈 **Capital Gains**: From investments (if any)
💼 **Other Sources**: Interest, dividends etc.

What's your approximate total annual income?`,
        quickOptions: ['Below ₹50 lakhs', 'Above ₹50 lakhs', 'Need calculation help']
      };
    }
    
    return {
      message: "I need to know your income range to suggest the right ITR form. Is your total annual income below or above ₹50 lakhs?",
      quickOptions: ['Below ₹50 lakhs', 'Above ₹50 lakhs', 'Not sure']
    };
  }
  
  // Check other income sources
  if (currentStep === 'check_other_income') {
    if (containsKeywords(message, ['only salary', 'just salary', 'salary only'])) {
      updateConversationState(sessionId, 'itr1_recommendation', { finalForm: 'ITR-1' });
      return {
        message: getITR1Recommendation(),
        quickOptions: ['Proceed with ITR-1', 'Document checklist', 'Tax calculation']
      };
    }
    
    if (containsKeywords(message, ['house', 'property', 'rental', 'rent'])) {
      updateConversationState(sessionId, 'itr2_recommendation', { finalForm: 'ITR-2', reason: 'house_property' });
      return {
        message: "Since you have house property income along with salary, you need to file ITR-2. Ready to proceed?",
        quickOptions: ['Yes, proceed with ITR-2', 'Document checklist', 'Tell me more']
      };
    }
    
    if (containsKeywords(message, ['capital', 'gains', 'shares', 'mutual fund', 'stocks'])) {
      updateConversationState(sessionId, 'check_capital_gains_amount');
      return {
        message: "You have capital gains. Is your Long Term Capital Gains under section 112A less than ₹1.25 lakhs?",
        quickOptions: ['Yes, under ₹1.25L', 'No, above ₹1.25L', 'What is section 112A?']
      };
    }
    
    if (containsKeywords(message, ['other', 'sources', 'interest', 'dividend'])) {
      updateConversationState(sessionId, 'itr2_recommendation', { finalForm: 'ITR-2', reason: 'other_sources' });
      return {
        message: "Since you have other sources of income, you need to file ITR-2. Shall we proceed with the filing process?",
        quickOptions: ['Yes, proceed with ITR-2', 'Document checklist', 'What documents needed?']
      };
    }
    
    return {
      message: "Apart from salary, do you have income from house property, capital gains, or other sources?",
      quickOptions: ['Only salary', 'House property', 'Capital gains', 'Other sources']
    };
  }
  
  // ITR-1 recommendation flow
  if (currentStep === 'itr1_recommendation') {
    if (containsKeywords(message, ['proceed', 'yes', 'start', 'itr-1'])) {
      updateConversationState(sessionId, 'choose_tax_regime');
      return {
        message: "Great! Let's proceed with ITR-1. First, you need to choose your tax regime. Which tax regime do you want to use?",
        quickOptions: ['New tax regime', 'Old tax regime', 'Which is better for me?']
      };
    }
    
    if (containsKeywords(message, ['document', 'checklist', 'papers'])) {
      return {
        message: getITR1Documents(),
        quickOptions: ['Proceed with ITR-1', 'Tax calculation', 'I have documents']
      };
    }
    
    if (containsKeywords(message, ['tax', 'calculation', 'calculate'])) {
      updateConversationState(sessionId, 'tax_calculation');
      return {
        message: "Let me help you calculate your tax. What's your gross annual salary (before deductions)?",
        quickOptions: ['Enter amount', 'Need help', 'Use tax calculator']
      };
    }
    
    return {
      message: getITR1Recommendation(),
      quickOptions: ['Proceed with ITR-1', 'Document checklist', 'Tax calculation']
    };
  }
  
  // Choose tax regime
  if (currentStep === 'choose_tax_regime') {
    if (containsKeywords(message, ['new', 'regime', 'new regime'])) {
      updateConversationState(sessionId, 'filing_guidance', { taxRegime: 'new' });
      return {
        message: "You've selected the New Tax Regime. This offers lower tax rates but limited deductions. Ready to proceed with the filing process?",
        quickOptions: ['Yes, start filing', 'Show me the process', 'Change to old regime']
      };
    }
    
    if (containsKeywords(message, ['old', 'regime', 'old regime'])) {
      updateConversationState(sessionId, 'filing_guidance', { taxRegime: 'old' });
      return {
        message: "You've selected the Old Tax Regime. This allows more deductions but has higher tax rates. Ready to proceed with filing?",
        quickOptions: ['Yes, start filing', 'Show me the process', 'Change to new regime']
      };
    }
    
    if (containsKeywords(message, ['which', 'better', 'compare', 'help'])) {
      return {
        message: getTaxRegimeComparison(),
        quickOptions: ['New tax regime', 'Old tax regime', 'Calculate for me']
      };
    }
    
    return {
      message: "Please choose your tax regime. This affects your tax calculation and available deductions.",
      quickOptions: ['New tax regime', 'Old tax regime', 'Which is better?']
    };
  }
  
  // Filing guidance - Final step
  if (currentStep === 'filing_guidance') {
    const formType = userData.finalForm || 'ITR-1';
    const taxRegime = userData.taxRegime || 'selected';
    
    if (containsKeywords(message, ['yes', 'start', 'filing', 'proceed'])) {
      updateConversationState(sessionId, 'filing_complete', { status: 'completed' });
      return {
        message: getFilingGuidance(formType, taxRegime),
        quickOptions: ['Download ITR form', 'E-filing portal', 'Need help with filing']
      };
    }
    
    if (containsKeywords(message, ['process', 'show', 'steps'])) {
      return {
        message: getFilingProcess(formType),
        quickOptions: ['Start filing now', 'Document checklist', 'Tax calculation']
      };
    }
    
    return {
      message: `Perfect! You're all set to file ${formType} using ${taxRegime} tax regime. Ready to begin the actual filing process?`,
      quickOptions: ['Yes, start filing', 'Show me the process', 'I have questions']
    };
  }
  
  // Default fallback
  return {
    message: "I didn't understand that. Let me help you with your ITR filing. What would you like to do?",
    quickOptions: ['Start filing process', 'Help', 'Which ITR form?', 'Start over']
  };
}

// Helper functions
function getITRFormGuide(): string {
  return `🔍 **ITR Form Selection Guide:**

📝 **ITR-1 (Sahaj)**: Salary, pension, one house property, other sources < ₹50L
📄 **ITR-2**: Salary + capital gains/multiple house properties, income > ₹50L  
📊 **ITR-3**: Business/Professional income (regular taxation)
📋 **ITR-4 (Sugam)**: Business/Professional with presumptive taxation
🏢 **ITR-5**: LLP, AOP, BOI, Trusts
🏭 **ITR-6**: Companies
🏛️ **ITR-7**: Trusts, political parties

Which income sources do you have?`;
}

function getAadhaarLinkingGuide(): string {
  return `🔗 **Link Aadhaar with PAN:**

**Online Methods:**
• 🌐 IT e-filing portal: incometax.gov.in
• 📱 SMS: Send to 567678 or 56161
• 🔗 Direct link: eportal.incometax.gov.in/iec/foservices

**Required Information:**
• PAN Number
• Aadhaar Number  
• Name (as per Aadhaar)

**Time Required:** Usually instant

Have you completed the linking process?`;
}

function getMultipleIncomeGuide(): string {
  return `🔄 **Multiple Income Sources Guide:**

**Common Combinations:**
💼 **Salary + Capital Gains** → ITR-2
🏠 **Salary + House Property** → ITR-2
💰 **Salary + Other Sources** → ITR-2
🏢 **Business + Other Income** → ITR-3
📈 **Professional + Investment** → ITR-3

**Key Points:**
• Multiple sources usually require ITR-2 or ITR-3
• ITR-1 only for simple salary cases
• Business income needs ITR-3 or ITR-4

What's your income combination?`;
}

function getITR1Recommendation(): string {
  return `✅ **ITR-1 (Sahaj) Recommended for you!**

**Perfect for:**
• 💰 Salary income only
• 🏠 Income < ₹50 lakhs
• 🎯 Simple tax situation

**Benefits:**
• ⚡ Quick and easy filing
• 📱 Mobile-friendly
• 🎨 User-friendly interface
• ⏱️ Minimal time required

**Next Steps:**
1. Choose tax regime
2. Enter personal details
3. Input salary details  
4. Submit and e-verify

Ready to proceed?`;
}

function getITR1Documents(): string {
  return `📄 **ITR-1 Document Checklist:**

**Essential Documents:**
• 📋 Form-16 from employer
• 💳 Salary slips (all months)
• 📊 TDS certificates
• 🏦 Bank interest certificates
• 💰 Investment proofs (80C)

**Optional (if applicable):**
• 🏠 House rent receipts (HRA)
• 🏥 Medical bills (80D)
• 📚 Donation receipts (80G)
• 💳 PAN card copy
• 🆔 Aadhaar card copy

**Digital Copies:** Keep all documents ready in PDF format

Do you have all required documents?`;
}

function getTaxRegimeComparison(): string {
  return `⚖️ **Tax Regime Comparison:**

**🆕 New Regime:**
✅ Lower tax rates
❌ Limited deductions
✅ Simple calculation
❌ No 80C, HRA benefits

**🔄 Old Regime:**
❌ Higher tax rates
✅ Multiple deductions available
❌ Complex calculations  
✅ 80C, HRA, home loan benefits

**Recommendation:**
• New: If minimal investments/deductions
• Old: If significant 80C, HRA, home loan

**Tip:** You can switch regimes each year!

Which regime suits your situation?`;
}

function getFilingGuidance(formType: string, taxRegime: string): string {
  return `🎉 **Ready to File ${formType}!**

**Your Configuration:**
• 📄 Form: ${formType}
• ⚖️ Tax Regime: ${taxRegime.charAt(0).toUpperCase() + taxRegime.slice(1)}
• 📅 Assessment Year: 2025-26

**Filing Steps:**
1. 🌐 Visit: incometax.gov.in
2. 🔐 Login with PAN & password
3. 📝 Select ${formType} form
4. 📊 Enter income details
5. 💰 Calculate tax
6. 📤 Submit return
7. ✅ E-verify within 120 days

**Estimated Time:** 30-45 minutes

**Support:** 1800-180-1961 (IT Helpdesk)

Good luck with your filing! 🍀`;
}

function getFilingProcess(formType: string): string {
  return `📋 **${formType} Filing Process:**

**Step-by-Step Guide:**

**1. Preparation (10 mins)**
• Gather all documents
• Keep PAN, Aadhaar ready
• Ensure bank details are correct

**2. Online Filing (20-30 mins)**
• Login to IT portal
• Select ${formType} form
• Fill personal information
• Enter income details
• Claim deductions
• Review and submit

**3. E-verification (5 mins)**
• Use Aadhaar OTP (recommended)
• Or use net banking/demat account
• Complete within 120 days

**4. Track Status**
• Check processing status
• Download ITR-V
• Track refund (if applicable)

Ready to start?`;
}