import React from 'react';
import { quickQuestions } from '../data/itrData';

interface QuickActionsProps {
  onQuestionSelect: (question: string) => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({ onQuestionSelect }) => {
  const popularQuestions = quickQuestions.slice(0, 4);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">Quick Questions</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {popularQuestions.map((q) => (
          <button
            key={q.id}
            onClick={() => onQuestionSelect(q.question)}
            className="text-left p-3 bg-gray-50 hover:bg-blue-50 hover:border-blue-200 border border-gray-200 rounded-lg transition-all duration-200 text-sm text-gray-700 hover:text-blue-700"
          >
            {q.question}
          </button>
        ))}
      </div>
    </div>
  );
};