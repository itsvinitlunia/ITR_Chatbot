import React from 'react';
import { categories } from '../data/itrData';
import { CategoryDropdown } from './CategoryDropdown';
import { 
  FileText, 
  Calculator, 
  Upload, 
  Clock, 
  FolderOpen, 
  RefreshCw 
} from 'lucide-react';

const iconMap = {
  FileText,
  Calculator,
  Upload,
  Clock,
  FolderOpen,
  RefreshCw
};

interface CategoryGridProps {
}

export const CategoryGrid: React.FC<CategoryGridProps> = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
      {categories.map((category) => {
        const IconComponent = iconMap[category.icon as keyof typeof iconMap];
        
        return (
          <CategoryDropdown
            key={category.id}
            categoryName={category.name}
            categoryIcon={<IconComponent className="text-blue-600" size={24} />}
          />
        );
      })}
    </div>
  );
};