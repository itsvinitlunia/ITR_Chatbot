import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { ChatInterface } from './ChatInterface';
import { Message } from '../types';
import { processChatMessage } from '../utils/chatbotLogic';

export const ChatbotButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);

  const handleSendMessage = (userMessage: string) => {
    // Add user message
    const userMsg: Message = {
      id: Date.now().toString(),
      text: userMessage,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);

    // Simulate bot response delay
    setTimeout(() => {
      const chatResponse = processChatMessage(userMessage, sessionId);
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: chatResponse.message,
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMsg]);
      
      // Add quick options as separate messages if available
      if (chatResponse.quickOptions && chatResponse.quickOptions.length > 0) {
        setTimeout(() => {
          const optionsMsg: Message = {
            id: (Date.now() + 2).toString(),
            text: `Quick options:\n${chatResponse.quickOptions!.map((option, index) => `${index + 1}. ${option}`).join('\n')}`,
            isUser: false,
            timestamp: new Date(),
            isQuickOptions: true
          };
          setMessages(prev => [...prev, optionsMsg]);
        }, 500);
      }
    }, 1500);
  };

  const handleQuickOptionClick = (option: string) => {
    handleSendMessage(option);
  };
  return (
    <>
      {/* Floating Chatbot Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center z-50 hover:scale-110"
      >
        <MessageCircle size={24} />
      </button>

      {/* Chatbot Modal */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl h-[600px] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-green-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white">
                  <MessageCircle size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">ITR Chat Assistant</h3>
                  <p className="text-sm text-gray-600">Ask me anything about ITR filing</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Chat Interface */}
            <div className="flex-1 overflow-hidden">
              <ChatInterface 
                messages={messages} 
                onSendMessage={handleSendMessage}
                showInput={true}
                onQuickOptionClick={handleQuickOptionClick}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};