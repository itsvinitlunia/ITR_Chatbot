import { QuickQuestion, Category } from '../types';

export const categories: Category[] = [
  {
    id: 'forms',
    name: 'ITR Forms',
    icon: 'FileText',
    description: 'Different types of ITR forms and when to use them'
  },
  {
    id: 'deductions',
    name: 'Deductions',
    icon: 'Calculator',
    description: 'Tax deductions under various sections'
  },
  {
    id: 'filing',
    name: 'Filing Process',
    icon: 'Upload',
    description: 'Step-by-step filing guidance'
  },
  {
    id: 'deadlines',
    name: 'Deadlines',
    icon: 'Clock',
    description: 'Important dates and deadlines'
  },
  {
    id: 'documents',
    name: 'Documents',
    icon: 'FolderOpen',
    description: 'Required documents for filing'
  },
  {
    id: 'refund',
    name: 'Refund Status',
    icon: 'RefreshCw',
    description: 'How to check and track refunds'
  }
];

export const quickQuestions: QuickQuestion[] = [
  {
    id: '1',
    question: 'Which ITR form should I use?',
    answer: 'The ITR form depends on your income sources:\n\n• ITR-1 (Sahaj): For salary income up to ₹50 lakhs, house property income, and other sources\n• ITR-2: For individuals with capital gains, foreign income, or multiple house properties\n• ITR-3: For business/profession income\n• ITR-4 (Sugam): For presumptive business income\n\nMost salaried individuals use ITR-1.',
    category: 'forms'
  },
  {
    id: '2',
    question: 'What is the deadline for filing ITR?',
    answer: 'Key ITR filing deadlines:\n\n• July 31st: For individuals (ITR-1, ITR-4)\n• October 31st: For audit cases and ITR-2, ITR-3\n• November 30th: For companies\n\nLate filing attracts penalties starting from ₹1,000. File before the deadline to avoid penalties.',
    category: 'deadlines'
  },
  {
    id: '3',
    question: 'What documents do I need for ITR filing?',
    answer: 'Essential documents for ITR filing:\n\n• Form 16 (from employer)\n• Bank statements\n• Interest certificates\n• Investment proofs (80C, 80D, etc.)\n• House property documents\n• Capital gains statements\n• PAN card\n• Aadhaar card\n• Previous year\'s ITR (if applicable)',
    category: 'documents'
  },
  {
    id: '4',
    question: 'How can I claim deductions under Section 80C?',
    answer: 'Section 80C deductions (up to ₹1.5 lakhs):\n\n• PPF contributions\n• ELSS mutual funds\n• Life insurance premiums\n• Home loan principal repayment\n• NSC, FD (5+ years)\n• Children\'s tuition fees\n• ULIP premiums\n\nKeep investment receipts and certificates for claiming these deductions.',
    category: 'deductions'
  },
  {
    id: '5',
    question: 'How to check ITR refund status?',
    answer: 'Check ITR refund status:\n\n1. Visit income tax e-filing portal\n2. Login with PAN and password\n3. Go to "View Returns/Forms"\n4. Check processing status\n\nAlternatively:\n• SMS "ITRSTATUS <PAN>" to 57575\n• Call 1800-180-1961\n• Use NSDL TIN website\n\nRefunds are usually processed within 45 days of successful verification.',
    category: 'refund'
  },
  {
    id: '6',
    question: 'What is the step-by-step ITR filing process?',
    answer: 'ITR filing process:\n\n1. Register on income tax e-filing portal\n2. Choose appropriate ITR form\n3. Fill personal information\n4. Enter income details from Form 16\n5. Claim deductions and exemptions\n6. Verify tax calculation\n7. Submit return online\n8. E-verify using Aadhaar OTP, Net banking, or EVC\n\nAlternatively, send signed ITR-1 by post within 120 days.',
    category: 'filing'
  },
  {
    id: '7',
    question: 'Can I revise my ITR after filing?',
    answer: 'Yes, you can revise your ITR:\n\n• Revision allowed until March 31st of the assessment year\n• Or before completion of assessment (whichever is earlier)\n• Use the same ITR form with "Revised" option\n• Mention the original acknowledgment number\n\nRevision is useful for correcting errors or claiming missed deductions.',
    category: 'filing'
  },
  {
    id: '8',
    question: 'What are the penalties for late ITR filing?',
    answer: 'ITR late filing penalties:\n\n• ₹1,000 if filed by December 31st\n• ₹5,000 if filed after December 31st\n• ₹10,000 for income above ₹20 lakhs\n\nAdditional consequences:\n• Interest on unpaid tax (1% per month)\n• Cannot carry forward losses\n• Processing delays\n\nFile on time to avoid these penalties!',
    category: 'deadlines'
  }
];

export const getAnswerForQuestion = (question: string): string => {
  const lowerQuestion = question.toLowerCase();
  
  // Enhanced keyword matching with more comprehensive coverage
  
  // ITR Forms related questions
  if (lowerQuestion.includes('form') || lowerQuestion.includes('itr-1') || lowerQuestion.includes('itr-2') || 
      lowerQuestion.includes('itr-3') || lowerQuestion.includes('itr-4') || lowerQuestion.includes('which form') ||
      lowerQuestion.includes('what form') || lowerQuestion.includes('sahaj') || lowerQuestion.includes('sugam')) {
    return quickQuestions.find(q => q.id === '1')?.answer || 'Please contact a tax professional for specific form guidance.';
  }
  
  // Deadline related questions
  if (lowerQuestion.includes('deadline') || lowerQuestion.includes('last date') || lowerQuestion.includes('due date') ||
      lowerQuestion.includes('when to file') || lowerQuestion.includes('july') || lowerQuestion.includes('october') ||
      lowerQuestion.includes('time limit') || lowerQuestion.includes('filing date')) {
    return quickQuestions.find(q => q.id === '2')?.answer || 'The general deadline is July 31st for most individuals.';
  }
  
  // Documents related questions
  if (lowerQuestion.includes('document') || lowerQuestion.includes('paper') || lowerQuestion.includes('form 16') ||
      lowerQuestion.includes('certificate') || lowerQuestion.includes('proof') || lowerQuestion.includes('what do i need') ||
      lowerQuestion.includes('required') || lowerQuestion.includes('bank statement') || lowerQuestion.includes('pan card')) {
    return quickQuestions.find(q => q.id === '3')?.answer || 'You\'ll need Form 16, bank statements, and investment proofs.';
  }
  
  // Deductions related questions
  if (lowerQuestion.includes('80c') || lowerQuestion.includes('deduction') || lowerQuestion.includes('tax saving') ||
      lowerQuestion.includes('investment') || lowerQuestion.includes('ppf') || lowerQuestion.includes('elss') ||
      lowerQuestion.includes('life insurance') || lowerQuestion.includes('save tax') || lowerQuestion.includes('exemption') ||
      lowerQuestion.includes('80d') || lowerQuestion.includes('medical') || lowerQuestion.includes('health insurance')) {
    return quickQuestions.find(q => q.id === '4')?.answer || 'Section 80C allows deductions up to ₹1.5 lakhs for eligible investments.';
  }
  
  // Refund related questions
  if (lowerQuestion.includes('refund') || lowerQuestion.includes('status') || lowerQuestion.includes('money back') ||
      lowerQuestion.includes('return money') || lowerQuestion.includes('check refund') || lowerQuestion.includes('track') ||
      lowerQuestion.includes('processing') || lowerQuestion.includes('when will i get')) {
    return quickQuestions.find(q => q.id === '5')?.answer || 'Check refund status on the income tax e-filing portal.';
  }
  
  // Filing process related questions
  if (lowerQuestion.includes('process') || lowerQuestion.includes('how to file') || lowerQuestion.includes('steps') ||
      lowerQuestion.includes('procedure') || lowerQuestion.includes('filing') || lowerQuestion.includes('submit') ||
      lowerQuestion.includes('e-filing') || lowerQuestion.includes('online') || lowerQuestion.includes('portal') ||
      lowerQuestion.includes('register') || lowerQuestion.includes('login')) {
    return quickQuestions.find(q => q.id === '6')?.answer || 'Register on e-filing portal, choose form, fill details, and e-verify.';
  }
  
  // Revision related questions
  if (lowerQuestion.includes('revise') || lowerQuestion.includes('correction') || lowerQuestion.includes('mistake') ||
      lowerQuestion.includes('error') || lowerQuestion.includes('change') || lowerQuestion.includes('modify') ||
      lowerQuestion.includes('update') || lowerQuestion.includes('wrong') || lowerQuestion.includes('rectify')) {
    return quickQuestions.find(q => q.id === '7')?.answer || 'You can revise ITR until March 31st of the assessment year.';
  }
  
  // Penalty related questions
  if (lowerQuestion.includes('penalty') || lowerQuestion.includes('late') || lowerQuestion.includes('fine') ||
      lowerQuestion.includes('charges') || lowerQuestion.includes('fee') || lowerQuestion.includes('interest') ||
      lowerQuestion.includes('missed deadline') || lowerQuestion.includes('delayed')) {
    return quickQuestions.find(q => q.id === '8')?.answer || 'Late filing penalty starts from ₹1,000. File before the deadline.';
  }
  
  // Additional specific questions
  
  // Salary related
  if (lowerQuestion.includes('salary') || lowerQuestion.includes('employee') || lowerQuestion.includes('job') ||
      lowerQuestion.includes('employer') || lowerQuestion.includes('tds')) {
    return 'For salaried individuals:\n\n• Use ITR-1 (Sahaj) if your salary is up to ₹50 lakhs\n• You\'ll need Form 16 from your employer\n• TDS details will be pre-filled from Form 16\n• Claim deductions under Section 80C, 80D, etc.\n• Most salaried people can file ITR-1 unless they have other income sources';
  }
  
  // Business/Professional income
  if (lowerQuestion.includes('business') || lowerQuestion.includes('profession') || lowerQuestion.includes('self employed') ||
      lowerQuestion.includes('freelance') || lowerQuestion.includes('consultant')) {
    return 'For business/professional income:\n\n• Use ITR-3 for business or professional income\n• Use ITR-4 (Sugam) for presumptive business income\n• Maintain proper books of accounts\n• Calculate income after business expenses\n• May need to get accounts audited if turnover exceeds limits';
  }
  
  // Capital gains
  if (lowerQuestion.includes('capital gain') || lowerQuestion.includes('shares') || lowerQuestion.includes('mutual fund') ||
      lowerQuestion.includes('property sale') || lowerQuestion.includes('stock') || lowerQuestion.includes('equity')) {
    return 'For capital gains:\n\n• Use ITR-2 if you have capital gains\n• Short-term gains (held <1 year): Taxed as per slab\n• Long-term gains on equity (held >1 year): 10% above ₹1 lakh\n• Long-term gains on property: 20% with indexation\n• Keep purchase/sale documents ready';
  }
  
  // House property
  if (lowerQuestion.includes('house') || lowerQuestion.includes('property') || lowerQuestion.includes('rent') ||
      lowerQuestion.includes('home loan') || lowerQuestion.includes('housing loan')) {
    return 'For house property income:\n\n• Rental income is taxable under "Income from House Property"\n• Deduct 30% standard deduction from rental income\n• Home loan interest up to ₹2 lakhs can be claimed\n• For self-occupied property, claim up to ₹2 lakhs interest deduction\n• Use ITR-1 for one house property, ITR-2 for multiple properties';
  }
  
  // Age-related queries
  if (lowerQuestion.includes('senior citizen') || lowerQuestion.includes('60 years') || lowerQuestion.includes('old age') ||
      lowerQuestion.includes('pension') || lowerQuestion.includes('retired')) {
    return 'For senior citizens (60+ years):\n\n• Higher basic exemption limit: ₹3 lakhs\n• Super senior citizens (80+): ₹5 lakhs exemption\n• Additional deduction of ₹50,000 under Section 80TTB for interest income\n• Medical insurance premium deduction up to ₹50,000 under 80D\n• Same ITR forms apply based on income sources';
  }
  
  // Tax calculation
  if (lowerQuestion.includes('tax calculation') || lowerQuestion.includes('how much tax') || lowerQuestion.includes('calculate tax') ||
      lowerQuestion.includes('tax amount') || lowerQuestion.includes('tax liability')) {
    return 'Tax calculation basics:\n\n• Income up to ₹2.5 lakhs: No tax\n• ₹2.5-5 lakhs: 5%\n• ₹5-10 lakhs: 20%\n• Above ₹10 lakhs: 30%\n• Add 4% Health & Education Cess\n• Claim deductions under 80C (₹1.5L), 80D, etc.\n• Use the tax calculator on income tax portal for accurate calculation';
  }
  
  // E-verification
  if (lowerQuestion.includes('verify') || lowerQuestion.includes('verification') || lowerQuestion.includes('otp') ||
      lowerQuestion.includes('aadhaar') || lowerQuestion.includes('net banking') || lowerQuestion.includes('evc')) {
    return 'ITR E-verification methods:\n\n• Aadhaar OTP (most common)\n• Net banking of select banks\n• Bank account number + debit card\n• EVC (Electronic Verification Code)\n• Physical verification by sending signed ITR-V within 120 days\n\nE-verification must be completed within 120 days of filing.';
  }
  
  // Common errors
  if (lowerQuestion.includes('error') || lowerQuestion.includes('problem') || lowerQuestion.includes('issue') ||
      lowerQuestion.includes('not working') || lowerQuestion.includes('failed')) {
    return 'Common ITR filing issues:\n\n• Form 16 mismatch: Check TDS details with AIS/26AS\n• Bank account validation failed: Ensure correct IFSC code\n• Aadhaar linking: Link PAN with Aadhaar before filing\n• Technical errors: Try different browser or clear cache\n• Validation errors: Check all mandatory fields\n\nFor persistent issues, contact IT helpdesk: 1800-180-1961';
  }
  
  // Greetings and general queries
  if (lowerQuestion.includes('hello') || lowerQuestion.includes('hi') || lowerQuestion.includes('help') ||
      lowerQuestion.includes('assist') || lowerQuestion.includes('guide')) {
    return 'Hello! I\'m here to help you with ITR filing. You can ask me about:\n\n• Which ITR form to use\n• Filing deadlines and process\n• Required documents\n• Tax deductions and exemptions\n• Refund status and tracking\n• Common filing issues\n\nWhat specific aspect of ITR filing would you like help with?';
  }
  
  // Default response for unmatched questions - more helpful
  return `I understand you have a question about ITR filing. While I may not have a specific answer for "${question}", here are some ways I can help:\n\n• Ask about "ITR forms" - Which form to use\n• Ask about "deductions" - Tax saving options\n• Ask about "filing process" - Step-by-step guidance\n• Ask about "deadlines" - Important dates\n• Ask about "documents" - What you need\n• Ask about "refund status" - How to check\n\nYou can also try rephrasing your question or contact a tax professional for complex queries. What specific aspect would you like to know about?`;
};