import React, { useState } from 'react';
import { ChevronDown, MessageCircle } from 'lucide-react';
import { quickQuestions, QuickQuestion } from '../data/itrData';

interface CategoryDropdownProps {
  categoryName: string;
  categoryIcon: React.ReactNode;
}

export const CategoryDropdown: React.FC<CategoryDropdownProps> = ({ 
  categoryName, 
  categoryIcon
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState<QuickQuestion | null>(null);
  
  // Filter questions by category
  const categoryQuestions = quickQuestions.filter(q => 
    q.category === getCategoryId(categoryName)
  );

  function getCategoryId(name: string): string {
    const categoryMap: { [key: string]: string } = {
      'ITR Forms': 'forms',
      'Deductions': 'deductions',
      'Filing Process': 'filing',
      'Deadlines': 'deadlines',
      'Documents': 'documents',
      'Refund Status': 'refund'
    };
    return categoryMap[name] || 'general';
  }

  const handleQuestionClick = (question: QuickQuestion) => {
    setSelectedQuestion(question);
  };

  const handleBackToQuestions = () => {
    setSelectedQuestion(null);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md hover:border-blue-300 transition-all duration-200 text-center group"
      >
        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-200 transition-colors">
          {categoryIcon}
        </div>
        <h3 className="font-semibold text-gray-800 text-sm mb-1 flex items-center justify-center gap-2">
          {categoryName}
          <ChevronDown 
            size={16} 
            className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
          />
        </h3>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 z-10 max-h-80 overflow-y-auto">
          {!selectedQuestion ? (
            <div className="p-2">
              {categoryQuestions.length > 0 && (
                <>
                  <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                    Common Questions
                  </div>
                  {categoryQuestions.map((question) => (
                    <button
                      key={question.id}
                      onClick={() => handleQuestionClick(question)}
                      className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-md transition-colors"
                    >
                      {question.question}
                    </button>
                  ))}
                </>
              )}
            </div>
          ) : (
            <div className="p-4">
              <button
                onClick={handleBackToQuestions}
                className="text-blue-600 text-sm mb-3 hover:text-blue-800 transition-colors"
              >
                ← Back to questions
              </button>
              <h4 className="font-semibold text-gray-800 mb-3 text-sm">
                {selectedQuestion.question}
              </h4>
              <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
                {selectedQuestion.answer}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};