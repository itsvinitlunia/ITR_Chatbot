import React from 'react';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';

export const ImportantDates: React.FC = () => {
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const assessmentYear = `2025-26`;
  
  // Calculate days remaining for July 31st deadline
  const julyDeadline = new Date(currentYear, 6, 31); // July 31st
  if (julyDeadline < currentDate) {
    julyDeadline.setFullYear(currentYear + 1);
  }
  const daysRemaining = Math.ceil((julyDeadline.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const dates = [
    {
      label: 'ITR Filing Deadline',
      date: 'July 31, 2025',
      daysLeft: daysRemaining,
      icon: Calendar,
      urgent: daysRemaining <= 30
    },
    {
      label: 'Audit Cases',
      date: 'October 31, 2025',
      icon: Clock,
      urgent: false
    },
    {
      label: 'Assessment Year',
      date: assessmentYear,
      icon: AlertTriangle,
      urgent: false
    }
  ];

  return (
    <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-green-600 text-white py-6 mb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-6">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            ITR Filing Assistant 2025
          </h1>
          <p className="text-blue-100 text-lg">
            Your Complete Guide to Income Tax Return Filing
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {dates.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div 
                key={index}
                className={`bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20 ${
                  item.urgent ? 'ring-2 ring-yellow-400 bg-red-500/20' : ''
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <IconComponent size={20} className={item.urgent ? 'text-yellow-300' : 'text-blue-200'} />
                  <span className="font-semibold text-sm">{item.label}</span>
                </div>
                <div className="text-lg font-bold">{item.date}</div>
                {item.daysLeft && (
                  <div className={`text-sm mt-1 ${item.urgent ? 'text-yellow-200' : 'text-blue-200'}`}>
                    {item.daysLeft > 0 ? `${item.daysLeft} days remaining` : 'Deadline passed'}
                    {item.urgent && item.daysLeft > 0 && (
                      <span className="ml-2 px-2 py-1 bg-yellow-500 text-yellow-900 rounded-full text-xs font-medium">
                        URGENT
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};