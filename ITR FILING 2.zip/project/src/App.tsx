import React, { useState } from 'react';
import { QuickActions } from './components/QuickActions';
import { CategoryGrid } from './components/CategoryGrid';
import { ImportantDates } from './components/ImportantDates';
import { ChatbotButton } from './components/ChatbotButton';
import { Calculator, FileText, HelpCircle, Phone } from 'lucide-react';

function App() {
  const handleQuestionSelect = (question: string) => {
    // This function can be removed or used for other purposes
    console.log('Question selected:', question);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Important Dates Header */}
      <ImportantDates />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Main Content Area */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <HelpCircle size={24} />
              Get Help With ITR Filing
            </h2>
            <p className="text-gray-600 mb-6">
              Choose a category below to find answers to common questions, or use our AI chatbot for personalized assistance.
            </p>
            <CategoryGrid />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Quick Actions */}
            <div>
              <QuickActions onQuestionSelect={handleQuestionSelect} />
            </div>
            
            {/* Help Resources */}
            <div className="bg-gradient-to-r from-blue-500 to-green-500 rounded-lg p-6 text-white">
              <h3 className="text-xl font-semibold mb-3">Need Expert Help?</h3>
              <p className="text-blue-100 mb-4">
                Our certified tax professionals are available for personalized consultation and complex tax situations.
              </p>
              <div className="space-y-3">
                <button className="w-full bg-white text-blue-600 py-3 rounded-md font-medium hover:bg-blue-50 transition-colors">
                  Book Free Consultation
                </button>
                <div className="flex items-center justify-center gap-4 text-sm text-blue-100">
                  <span className="flex items-center gap-1">
                    <Phone size={16} />
                    1800-123-4567
                  </span>
                  <span>•</span>
                  <span>Available 24/7</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Disclaimer */}
          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              <strong>Disclaimer:</strong> This assistant provides general guidance only. 
              For complex tax situations, please consult with a qualified Chartered Accountant or tax advisor.
              Always refer to the latest Income Tax Act and official notifications.
            </p>
          </div>
        </div>
      </main>

      {/* Floating Chatbot Button */}
      <ChatbotButton />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Calculator size={20} />
                <span className="font-semibold">ITR Assistant</span>
              </div>
              <p className="text-gray-400 text-sm">
                Simplifying tax filing for millions of Indians with AI-powered assistance.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Tax Calculator</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Forms Download</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Expert Consultation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Tax News</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>📞 1800-123-4567</li>
                <li>📧 help@itrassistant.com</li>
                <li>🕒 24/7 Available</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>&copy; 2025 ITR Assistant. All rights reserved. | Privacy Policy | Terms of Service</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;